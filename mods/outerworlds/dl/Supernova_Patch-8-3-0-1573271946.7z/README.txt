The Supernova Patch mod, updated to work for latest game version. Tested with Steam version.
Download link: https://www.nexusmods.com/theouterworlds/mods/8
See this for details: https://forums.nexusmods.com/index.php?/topic/8096938-supernova-patch/page-40#entry99369573
